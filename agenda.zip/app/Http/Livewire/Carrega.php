<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Carrega extends Component
{
    public function render()
    {
        return view('livewire.carrega');
    }
}
