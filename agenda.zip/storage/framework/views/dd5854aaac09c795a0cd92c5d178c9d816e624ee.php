

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contato-m')->html();
} elseif ($_instance->childHasBeenRendered('AAbBJeY')) {
    $componentId = $_instance->getRenderedChildComponentId('AAbBJeY');
    $componentTag = $_instance->getRenderedChildComponentTagName('AAbBJeY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AAbBJeY');
} else {
    $response = \Livewire\Livewire::mount('contato-m');
    $html = $response->html();
    $_instance->logRenderedChild('AAbBJeY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\agenda\livewire\resources\views/usuarios/contatos.blade.php ENDPATH**/ ?>