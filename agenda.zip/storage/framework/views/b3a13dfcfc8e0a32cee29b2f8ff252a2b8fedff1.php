
<div>
    <div class="px-4 space-y-4 mt-8">
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Ops!</strong> algo deu  errado!.<br><br>
            <ul style="list-style-type:none;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session()->has('message4')): ?>
  
  <div class="alert alert-success">
              <?php echo e(session('message4')); ?>

             
          </div>
            
      <?php endif; ?>
    <?php if(session()->has('message5')): ?>
  
  <div class="alert alert-success">
              <?php echo e(session('message5')); ?>

             
          </div>
            
      <?php endif; ?>
      
        <form class='form-inline'>
        <?php echo $__env->make('livewire.update2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
            <input class="form-control border-solid border border-gray-300" 
                type="text" placeholder="Pesquise um contato" wire:model="pesquisa" wire:keydown.escape="reset" style="width:100%;"/>
        </form>
        <div wire:loading>Pesquisando contatos...</div>
        <div wire:loading.remove>
        <ul class="list-group" style="list-style-type: none;">
       <?php if(!empty($pesquisa)): ?>
            <?php if($contatos->isEmpty()): ?>
            <li class="list-group-item">
                    Nenhum contato encontrado.
                </li>
            <?php else: ?>
                <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <li class="list-group-item" style="border-bottom:none;">
                       <h6 class="text-lg text-gray-100 text-bold"><?php echo e($row->nome); ?> <?php echo e($row->ultimo_nome); ?></h6>
                        <p class="text-gray-100"><span class="font-weight-bold">Email</span>:<span class="font-italic font-weight-light"><?php echo e($row->email); ?></span>
                         - <span class="font-weight-bold">telefone</span>:<span class="font-italic font-weight-light"><?php echo e($row->telefone); ?></span>
                        </p>
                       
                   
                    </li>
                    <div style="background-color:white;display:grid; padding-top:3%;padding:2px;">
                    <button data-toggle="modal" data-target="#updateModal2"  wire:click="edit2(<?php echo e($row->id); ?>)" class="btn btn-sm btn-outline-primary py-0" >Editar</button>
                    <button data-toggle="modal" data-target="#deleteModalX<?php echo e($row->id); ?>"  class="btn btn-sm btn-outline-danger py-0">Deletar</button>
                       <?php echo $__env->make('livewire.deleta2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                  </div>
                    
                   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endif; ?>
        </ul>
        </div>
    </div>
    <div class="px-4 mt-4">
        
    </div>
</div><?php /**PATH C:\xampp\htdocs\agenda\livewire\resources\views/livewire/pesquisa.blade.php ENDPATH**/ ?>