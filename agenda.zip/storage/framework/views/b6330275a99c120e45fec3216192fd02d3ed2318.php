<footer class="bg-dark text-center text-white" style="padding-top:5%;margin-top:5%;">
  <!-- Grid container -->
  <div class="container p-4 pb-0">
   

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2021 ~
    <a class="text-white" href="#">Thélesson de Souza</a>
  </div>
  <!-- Copyright -->
</footer><?php /**PATH C:\xampp\htdocs\agenda\livewire\resources\views/partials/footer.blade.php ENDPATH**/ ?>