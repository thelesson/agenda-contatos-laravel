

<div class="row">

<div class="col-md-1"></div>
    <div class="col-md-10 col-sm-12 col-xs-12">

    
<!--conteudo-modal -->
<?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Ops!</strong> algo está errado!.<br><br>
            <ul style="list-style-type:none;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session()->has('message3')): ?>
  
    <div class="alert alert-success">
                <?php echo e(session('message3')); ?>

               
            </div>
              
        <?php endif; ?>

        <?php echo $__env->make('livewire.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('livewire.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       

    <table class="table table-hover table-responsive-md" style="margin-top:20px;">
        <tr>
            <td>ORDEM</td>
            <td>NOME</td>
            <td>ULTIMO NOME</td>
            <td>EMAIL</td>
            <td>TELEFONE</td>
            <td>AÇÕES</td>
        </tr>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($row->nome); ?></td>
                <td><?php echo e($row->ultimo_nome); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->telefone); ?></td>
                <td>
                <!-- Button trigger modal -->

                    <button data-toggle="modal" data-target="#updateModal"  wire:click="edit(<?php echo e($row->id); ?>)" class="btn btn-sm btn-outline-primary py-0" >Editar</button>
                    
                    <button data-toggle="modal" data-target="#deleteModal<?php echo e($row->id); ?>"  class="btn btn-sm btn-outline-danger py-0">Deletar</button>
                    <?php echo $__env->make('livewire.deleta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
    </div>
    <div class="col-md-1"></div>
</div> 
 <?php /**PATH C:\xampp\htdocs\agenda\livewire\resources\views/livewire/contato-m.blade.php ENDPATH**/ ?>