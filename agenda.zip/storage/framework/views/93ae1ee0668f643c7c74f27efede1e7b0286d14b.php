
<!-- Modal -->
<div wire:ignore.self class="modal fade" style="z-index:100000" id="deleteModalX<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Deletar Contato</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <h3>Deseja realmente deletar este contato?</h3>
        <!-- end -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
        <button  wire:click="destroy2(<?php echo e($row->id); ?>)"  data-dismiss="modal" class="btn btn-danger">Deletar</button>
        <div wire:loading.grid wire:target="destroy2">
  <div class="overlay2">
  <div class="row">
  <div class="col-md-12">
  <h3 class="text-center">Deletando Contato</h3>
        <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('carrega', [])->html();
} elseif ($_instance->childHasBeenRendered('xGdBsup')) {
    $componentId = $_instance->getRenderedChildComponentId('xGdBsup');
    $componentTag = $_instance->getRenderedChildComponentTagName('xGdBsup');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xGdBsup');
} else {
    $response = \Livewire\Livewire::mount('carrega', []);
    $html = $response->html();
    $_instance->logRenderedChild('xGdBsup', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> não aceitando refresh -->
        <?php echo $__env->make('livewire.carrega', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
          
    </div>
       
  </div>
  </div>
  </div>
 

    </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\agenda\livewire\resources\views/livewire/deleta2.blade.php ENDPATH**/ ?>