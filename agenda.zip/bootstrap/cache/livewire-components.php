<?php return array (
  'carrega' => 'App\\Http\\Livewire\\Carrega',
  'contato-m' => 'App\\Http\\Livewire\\ContatoM',
  'contato-x' => 'App\\Http\\Livewire\\ContatoX',
  'deleta' => 'App\\Http\\Livewire\\Deleta',
  'pesquisa' => 'App\\Http\\Livewire\\Pesquisa',
);