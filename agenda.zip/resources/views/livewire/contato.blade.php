
<div>
    
    <div class="col-md-6">

    

    @if($updateMode)
        @include('livewire.update')
    @else
        @include('livewire.create')
    @endif


    <table class="table table-striped" style="margin-top:20px;">
        <tr>
            <td>NO</td>
            <td>NOME</td>
            <td>ULTIMO NOME</td>
            <td>EMAIL</td>
            <td>TELEFONE NOME</td>
            <td>ACTION</td>
        </tr>

        @foreach($data as $row)
            <tr>
                <td>{{$loop->index + 1}}</td>
                <td>{{$row->nome}}</td>
                <td>{{$row->ultimo_nome}}</td>
                <td>{{$row->email}}</td>
                <td>{{$row->telefone}}</td>
                <td>
                    <button wire:click="edit({{$row->id}})" class="btn btn-sm btn-outline-danger py-0">Editar</button> | 
                    <button wire:click="destroy({{$row->id}})" class="btn btn-sm btn-outline-danger py-0">Deletar</button>
                </td>
            </tr>
        @endforeach
    </table>
    </div>

</div> 
 