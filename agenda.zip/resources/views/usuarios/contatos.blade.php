
@extends('layouts.app')
@section('content')
    <div class="flex justify-center">
        @livewire('contato-m')
    </div>
@endsection 